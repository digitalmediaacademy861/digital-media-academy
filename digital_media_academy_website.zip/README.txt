DIGITAL MEDIA ACADEMY WEBSITE

Files:
- index.html: complete responsive website (HTML, CSS, and JavaScript are included in one file).

The Video Editing Training and community buttons are connected to the WhatsApp invitation link supplied by you.
Graphic Design and More Digital Skills are marked Coming Soon.

FREE PUBLISHING OPTION: GitHub Pages
1. Sign in to GitHub or create a free account.
2. Create a new public repository named digital-media-academy.
3. Upload index.html to the repository's root (main) folder.
4. Open the repository's Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then save.
7. Wait for the publishing process. GitHub will show the live website address in Settings > Pages.

You can publish this site without buying a custom domain. The GitHub Pages address will depend on your GitHub username and repository settings.
